/**
 * BulletFactory - 子弹实体工厂
 * 
 * 提供创建子弹实体的工厂函数。
 */
const SpriteRenderer = require('../../../framework/components/SpriteRenderer');
const BulletComponent = require('../components/BulletComponent');

/**
 * 将 hex 颜色降低亮度
 * @param {string} hex - 十六进制颜色（如 '#ff00cc'）
 * @param {number} factor - 亮度系数 (0~1)，小于 1 变暗
 * @returns {string} 降低亮度后的 hex 颜色
 */
function darkenColor(hex, factor) {
  // 去掉 #
  let c = hex.replace('#', '');
  if (c.length === 3) {
    c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
  }
  const r = Math.round(parseInt(c.substring(0, 2), 16) * factor);
  const g = Math.round(parseInt(c.substring(2, 4), 16) * factor);
  const b = Math.round(parseInt(c.substring(4, 6), 16) * factor);
  return '#' +
    r.toString(16).padStart(2, '0') +
    g.toString(16).padStart(2, '0') +
    b.toString(16).padStart(2, '0');
}

/**
 * 创建子弹实体
 * 
 * @param {import('../../../framework/core/World')} world - 游戏世界
 * @param {number} x - 初始位置 X
 * @param {number} y - 初始位置 Y
 * @param {number} damage - 伤害值
 * @param {string} [color] - 角色颜色，子弹颜色会基于此降低亮度
 * @returns {import('../../../framework/core/Entity')} 创建的子弹实体
 */
function createBullet(world, x, y, damage, color) {
  const bullet = world.CreateEntity('bullet');
  const transform = bullet.GetComponent('Transform');
  transform.x = x;
  transform.y = y;

  // 子弹颜色：跟随角色颜色，亮度降低 30%
  const bulletColor = color ? darkenColor(color, 0.7) : '#b3b300';
  const borderColor = color ? darkenColor(color, 0.5) : '#ff8800';

  // 添加小圆形渲染器
  bullet.AddComponent(new SpriteRenderer({
    shape: 'circle',
    radius: 3,
    color: bulletColor,
    borderColor: borderColor,
    borderWidth: 1
  }));

  // 添加子弹组件
  bullet.AddComponent(new BulletComponent({
    damage: damage,
    speed: 300
  }));

  return bullet;
}

module.exports = {
  createBullet
};
