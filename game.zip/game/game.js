/**
 * 微信小游戏入口文件
 */
require('./js/main')();
